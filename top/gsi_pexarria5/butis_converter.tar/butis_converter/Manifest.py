files = [
   "pexaria.vhd",
   "pexaria.sdc"
]

modules = {
  "local" : [
    "../../..",
  ]
}
